var N = [
  {revision: null, url: '/_next/static/media/icon.1v-cwrpm-d3xw.svg'},
  {revision: null, url: '/_next/static/media/favicon.0eyyhwtli7m-q.ico'},
  {revision: null, url: '/_next/static/media/apple-icon.286e8tfvsrijs.png'},
  {revision: null, url: '/_next/static/chunks/turbopack-3pts-hkszx20u.js'},
  {revision: null, url: '/_next/static/chunks/3t_en2hvv2z1y.js'},
  {revision: null, url: '/_next/static/chunks/3s9q_0adjzq0v.js'},
  {revision: null, url: '/_next/static/chunks/3rkd2kosdwxns.js'},
  {revision: null, url: '/_next/static/chunks/3g7vq3yofehhp.js'},
  {revision: null, url: '/_next/static/chunks/3bmku-cfsyhyq.js'},
  {revision: null, url: '/_next/static/chunks/390t06t7wwzrg.js'},
  {revision: null, url: '/_next/static/chunks/36mwnsa94_nxs.js'},
  {revision: null, url: '/_next/static/chunks/35e1ro7-nhxo-.js'},
  {revision: null, url: '/_next/static/chunks/2ufncommjxmiq.js'},
  {revision: null, url: '/_next/static/chunks/2lb3eboqhg-rr.js'},
  {revision: null, url: '/_next/static/chunks/2iq0yfrhoftc7.js'},
  {revision: null, url: '/_next/static/chunks/2bte3tv_cj1xa.js'},
  {revision: null, url: '/_next/static/chunks/26ilkec4a8hz2.js'},
  {revision: null, url: '/_next/static/chunks/243c7_lud3q0x.js'},
  {revision: null, url: '/_next/static/chunks/21g_3r543w_a0.js'},
  {revision: null, url: '/_next/static/chunks/1zpoymf8qqs0j.js'},
  {revision: null, url: '/_next/static/chunks/1ylh86bvr4e17.js'},
  {revision: null, url: '/_next/static/chunks/1n8-xj1xwymbm.js'},
  {revision: null, url: '/_next/static/chunks/1id5ugz2yfr62.js'},
  {revision: null, url: '/_next/static/chunks/1gqfhtmz9m7u3.js'},
  {revision: null, url: '/_next/static/chunks/1c8j-tkph5ruo.js'},
  {revision: null, url: '/_next/static/chunks/18tvf0dp_hjft.js'},
  {revision: null, url: '/_next/static/chunks/17215i8k5qkj-.css'},
  {revision: null, url: '/_next/static/chunks/10yt784-qx4bt.css'},
  {revision: null, url: '/_next/static/chunks/0tx0bl1yvwuf8.js'},
  {revision: null, url: '/_next/static/chunks/0shtyzjm29huq.js'},
  {revision: null, url: '/_next/static/chunks/0ld00_5ct9cnh.js'},
  {revision: null, url: '/_next/static/chunks/0jug1dyumdfhk.js'},
  {revision: null, url: '/_next/static/chunks/0cz1d0mv5g_q7.js'},
  {revision: null, url: '/_next/static/chunks/0cgp61ufv29da.js'},
  {revision: null, url: '/_next/static/bVlPHsC97e04Ypi-5V7Z6/_ssgManifest.js'},
  {revision: null, url: '/_next/static/bVlPHsC97e04Ypi-5V7Z6/_clientMiddlewareManifest.js'},
  {revision: null, url: '/_next/static/bVlPHsC97e04Ypi-5V7Z6/_buildManifest.js'},
  {revision: 'fb51ce0641dbfaf77985bce562954814', url: '/icons/maskable-512.png'},
  {revision: 'e725fbca8654a075be1856c76fc7eed0', url: '/icons/maskable-192.png'},
  {revision: '83e7b6ab082e76b2615b0499f3a8cc08', url: '/icons/icon-512.png'},
  {revision: 'e30f2013624bcc196c8bf0211f6bcafe', url: '/icons/icon-192.png'},
  {revision: 'd2e3c272f842129ff7f7a88787ef42ce', url: '/brand/logo-reversed.svg'},
  {revision: '39d692202214c24e6d55d582c02c99c9', url: '/brand/logo-mark.svg'},
  {revision: 'febf80c701cc71fb6535779d7bb4e6e7', url: '/brand/logo-mark-reversed.svg'},
  {revision: 'e94ab7e5430b49f3d3a90361637df2ff', url: '/brand/logo-full.svg'},
  {revision: '0ee304dd2176c81eec0d28320338fa8b', url: '/~offline'},
  {revision: '3a0081ece8ff1c6bb5528d33693be7cd', url: '/testimonials'},
  {revision: 'a13fbd563eac900e244d7e4bfd268dff', url: '/programs'},
  {revision: '0fc4ae1543c686bdf95e8bca9bb458ae', url: '/montessori'},
  {revision: '9e72821521c5b5d6580c48399967fcc5', url: '/'},
  {revision: 'd7595f19467a4fe49b32464583a8ecf7', url: '/gallery'},
  {revision: '01b53bcab9eb644af546b9883e8bd506', url: '/about'},
  {revision: 'd41d8cd98f00b204e9800998ecf8427e', url: '/[slug]'},
  {revision: 'bf607720dca8d6af44afff02372fed0f', url: '/projects/__placeholder__'},
  {revision: 'd41d8cd98f00b204e9800998ecf8427e', url: '/projects/[slug]'},
  {revision: '8fe62ad6155cbd32f42b02c56962d31f', url: '/posts/__placeholder__'},
  {revision: 'd41d8cd98f00b204e9800998ecf8427e', url: '/posts/[slug]'},
  {revision: '563731aa2e403944c6d6a5a9349ec9b97a4e0772', url: '/~offline'},
]
var g = {
    googleAnalytics: 'googleAnalytics',
    precache: 'precache-v2',
    prefix: 'serwist',
    runtime: 'runtime',
    suffix: typeof registration < 'u' ? registration.scope : '',
  },
  L = (e) => [g.prefix, e, g.suffix].filter((t) => t && t.length > 0).join('-'),
  Be = (e) => {
    for (let t of Object.keys(g)) e(t)
  },
  m = {
    updateDetails: (e) => {
      Be((t) => {
        let s = e[t]
        typeof s == 'string' && (g[t] = s)
      })
    },
    getGoogleAnalyticsName: (e) => e || L(g.googleAnalytics),
    getPrecacheName: (e) => e || L(g.precache),
    getPrefix: () => g.prefix,
    getRuntimeName: (e) => e || L(g.runtime),
    getSuffix: () => g.suffix,
  },
  R
function Z() {
  if (R === void 0) {
    let e = new Response('')
    if ('body' in e)
      try {
        ;(new Response(e.body), (R = !0))
      } catch {
        R = !1
      }
    R = !1
  }
  return R
}
var je = (e, ...t) => {
  let s = e
  return (t.length > 0 && (s += ` :: ${JSON.stringify(t)}`), s)
}
var We = je,
  u = class extends Error {
    details
    constructor(e, t) {
      let s = We(e, t)
      ;(super(s), (this.name = e), (this.details = t))
    }
  }
var ee = (e) =>
  new URL(String(e), location.href).href.replace(new RegExp(`^${location.origin}`), '')
function x(e) {
  return new Promise((t) => setTimeout(t, e))
}
var V = new Set()
function X(e, t) {
  let s = new URL(e)
  for (let r of t) s.searchParams.delete(r)
  return s.href
}
async function te(e, t, s, r) {
  let a = X(t.url, s)
  if (t.url === a) return e.match(t, r)
  let n = {...r, ignoreSearch: !0},
    o = await e.keys(t, n)
  for (let i of o) if (a === X(i.url, s)) return e.match(i, r)
}
var se = class {
    promise
    resolve
    reject
    constructor() {
      this.promise = new Promise((e, t) => {
        ;((this.resolve = e), (this.reject = t))
      })
    }
  },
  re = async () => {
    for (let e of V) await e()
  },
  Ke = '-precache-',
  He = async (e, t = Ke) => {
    let s = (await self.caches.keys()).filter(
      (r) => r.includes(t) && r.includes(self.registration.scope) && r !== e,
    )
    return (await Promise.all(s.map((r) => self.caches.delete(r))), s)
  },
  ae = (e) => {
    self.addEventListener('activate', (t) => {
      t.waitUntil(He(m.getPrecacheName(e)).then((s) => {}))
    })
  },
  ne = () => {
    self.addEventListener('activate', () => self.clients.claim())
  },
  F = (e, t) => {
    let s = t()
    return (e.waitUntil(s), s)
  }
var j = (e, t) => t.some((s) => e instanceof s),
  oe,
  ie
function Ge() {
  return oe || (oe = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])
}
function Qe() {
  return (
    ie ||
    (ie = [
      IDBCursor.prototype.advance,
      IDBCursor.prototype.continue,
      IDBCursor.prototype.continuePrimaryKey,
    ])
  )
}
var W = new WeakMap(),
  M = new WeakMap(),
  k = new WeakMap()
function ze(e) {
  let t = new Promise((s, r) => {
    let a = () => {
        ;(e.removeEventListener('success', n), e.removeEventListener('error', o))
      },
      n = () => {
        ;(s(E(e.result)), a())
      },
      o = () => {
        ;(r(e.error), a())
      }
    ;(e.addEventListener('success', n), e.addEventListener('error', o))
  })
  return (k.set(t, e), t)
}
function Ye(e) {
  if (W.has(e)) return
  let t = new Promise((s, r) => {
    let a = () => {
        ;(e.removeEventListener('complete', n),
          e.removeEventListener('error', o),
          e.removeEventListener('abort', o))
      },
      n = () => {
        ;(s(), a())
      },
      o = () => {
        ;(r(e.error || new DOMException('AbortError', 'AbortError')), a())
      }
    ;(e.addEventListener('complete', n),
      e.addEventListener('error', o),
      e.addEventListener('abort', o))
  })
  W.set(e, t)
}
var K = {
  get(e, t, s) {
    if (e instanceof IDBTransaction) {
      if (t === 'done') return W.get(e)
      if (t === 'store')
        return s.objectStoreNames[1] ? void 0 : s.objectStore(s.objectStoreNames[0])
    }
    return E(e[t])
  },
  set(e, t, s) {
    return ((e[t] = s), !0)
  },
  has(e, t) {
    return e instanceof IDBTransaction && (t === 'done' || t === 'store') ? !0 : t in e
  },
}
function he(e) {
  K = e(K)
}
function Je(e) {
  return Qe().includes(e)
    ? function (...t) {
        return (e.apply(H(this), t), E(this.request))
      }
    : function (...t) {
        return E(e.apply(H(this), t))
      }
}
function Xe(e) {
  return typeof e == 'function'
    ? Je(e)
    : (e instanceof IDBTransaction && Ye(e), j(e, Ge()) ? new Proxy(e, K) : e)
}
function E(e) {
  if (e instanceof IDBRequest) return ze(e)
  if (M.has(e)) return M.get(e)
  let t = Xe(e)
  return (t !== e && (M.set(e, t), k.set(t, e)), t)
}
var H = (e) => k.get(e)
function O(e, t, {blocked: s, upgrade: r, blocking: a, terminated: n} = {}) {
  let o = indexedDB.open(e, t),
    i = E(o)
  return (
    r &&
      o.addEventListener('upgradeneeded', (c) => {
        r(E(o.result), c.oldVersion, c.newVersion, E(o.transaction), c)
      }),
    s && o.addEventListener('blocked', (c) => s(c.oldVersion, c.newVersion, c)),
    i
      .then((c) => {
        ;(n && c.addEventListener('close', () => n()),
          a && c.addEventListener('versionchange', (l) => a(l.oldVersion, l.newVersion, l)))
      })
      .catch(() => {}),
    i
  )
}
function de(e, {blocked: t} = {}) {
  let s = indexedDB.deleteDatabase(e)
  return (t && s.addEventListener('blocked', (r) => t(r.oldVersion, r)), E(s).then(() => {}))
}
var Ze = ['get', 'getKey', 'getAll', 'getAllKeys', 'count'],
  et = ['put', 'add', 'delete', 'clear'],
  B = new Map()
function ce(e, t) {
  if (!(e instanceof IDBDatabase && !(t in e) && typeof t == 'string')) return
  if (B.get(t)) return B.get(t)
  let s = t.replace(/FromIndex$/, ''),
    r = t !== s,
    a = et.includes(s)
  if (!(s in (r ? IDBIndex : IDBObjectStore).prototype) || !(a || Ze.includes(s))) return
  let n = async function (o, ...i) {
    let c = this.transaction(o, a ? 'readwrite' : 'readonly'),
      l = c.store
    return (r && (l = l.index(i.shift())), (await Promise.all([l[s](...i), a && c.done]))[0])
  }
  return (B.set(t, n), n)
}
he((e) => ({
  ...e,
  get: (t, s, r) => ce(t, s) || e.get(t, s, r),
  has: (t, s) => !!ce(t, s) || e.has(t, s),
}))
var tt = ['continue', 'continuePrimaryKey', 'advance'],
  le = {},
  G = new WeakMap(),
  pe = new WeakMap(),
  st = {
    get(e, t) {
      if (!tt.includes(t)) return e[t]
      let s = le[t]
      return (
        s ||
          (s = le[t] =
            function (...r) {
              G.set(this, pe.get(this)[t](...r))
            }),
        s
      )
    },
  }
async function* rt(...e) {
  let t = this
  if ((t instanceof IDBCursor || (t = await t.openCursor(...e)), !t)) return
  t = t
  let s = new Proxy(t, st)
  for (pe.set(s, t), k.set(s, H(t)); t;)
    (yield s, (t = await (G.get(s) || t.continue())), G.delete(s))
}
function ue(e, t) {
  return (
    (t === Symbol.asyncIterator && j(e, [IDBIndex, IDBObjectStore, IDBCursor])) ||
    (t === 'iterate' && j(e, [IDBIndex, IDBObjectStore]))
  )
}
he((e) => ({
  ...e,
  get(t, s, r) {
    return ue(t, s) ? rt : e.get(t, s, r)
  },
  has(t, s) {
    return ue(t, s) || e.has(t, s)
  },
}))
var we = async (e, t) => {
    let s = null
    if ((e.url && (s = new URL(e.url).origin), s !== self.location.origin))
      throw new u('cross-origin-copy-response', {origin: s})
    let r = e.clone(),
      a = {headers: new Headers(r.headers), status: r.status, statusText: r.statusText},
      n = t ? t(a) : a,
      o = Z() ? r.body : await r.blob()
    return new Response(o, n)
  },
  ye = () => {
    self.__WB_DISABLE_DEV_LOGS = !0
  },
  fe = 3,
  at = 'serwist-background-sync',
  w = 'requests',
  D = 'queueName',
  nt = class {
    _db = null
    async addEntry(e) {
      let t = (await this.getDb()).transaction(w, 'readwrite', {durability: 'relaxed'})
      ;(await t.store.add(e), await t.done)
    }
    async getFirstEntryId() {
      return (await (await this.getDb()).transaction(w).store.openCursor())?.value.id
    }
    async getAllEntriesByQueueName(e) {
      let t = await (await this.getDb()).getAllFromIndex(w, D, IDBKeyRange.only(e))
      return t || []
    }
    async getEntryCountByQueueName(e) {
      return (await this.getDb()).countFromIndex(w, D, IDBKeyRange.only(e))
    }
    async deleteEntry(e) {
      await (await this.getDb()).delete(w, e)
    }
    async getFirstEntryByQueueName(e) {
      return await this.getEndEntryFromIndex(IDBKeyRange.only(e), 'next')
    }
    async getLastEntryByQueueName(e) {
      return await this.getEndEntryFromIndex(IDBKeyRange.only(e), 'prev')
    }
    async getEndEntryFromIndex(e, t) {
      return (await (await this.getDb()).transaction(w).store.index(D).openCursor(e, t))?.value
    }
    async getDb() {
      return (this._db || (this._db = await O(at, fe, {upgrade: this._upgradeDb})), this._db)
    }
    _upgradeDb(e, t) {
      ;(t > 0 && t < fe && e.objectStoreNames.contains(w) && e.deleteObjectStore(w),
        e.createObjectStore(w, {autoIncrement: !0, keyPath: 'id'}).createIndex(D, D, {unique: !1}))
    }
  },
  Ne = class {
    _queueName
    _queueDb
    constructor(e) {
      ;((this._queueName = e), (this._queueDb = new nt()))
    }
    async pushEntry(e) {
      ;(delete e.id, (e.queueName = this._queueName), await this._queueDb.addEntry(e))
    }
    async unshiftEntry(e) {
      let t = await this._queueDb.getFirstEntryId()
      ;(t ? (e.id = t - 1) : delete e.id,
        (e.queueName = this._queueName),
        await this._queueDb.addEntry(e))
    }
    async popEntry() {
      return this._removeEntry(await this._queueDb.getLastEntryByQueueName(this._queueName))
    }
    async shiftEntry() {
      return this._removeEntry(await this._queueDb.getFirstEntryByQueueName(this._queueName))
    }
    async getAll() {
      return await this._queueDb.getAllEntriesByQueueName(this._queueName)
    }
    async size() {
      return await this._queueDb.getEntryCountByQueueName(this._queueName)
    }
    async deleteEntry(e) {
      await this._queueDb.deleteEntry(e)
    }
    async _removeEntry(e) {
      return (e && (await this.deleteEntry(e.id)), e)
    }
  },
  ot = [
    'method',
    'referrer',
    'referrerPolicy',
    'mode',
    'credentials',
    'cache',
    'redirect',
    'integrity',
    'keepalive',
  ],
  Y = class z {
    _requestData
    static async fromRequest(t) {
      let s = {url: t.url, headers: {}}
      ;(t.method !== 'GET' && (s.body = await t.clone().arrayBuffer()),
        t.headers.forEach((r, a) => {
          s.headers[a] = r
        }))
      for (let r of ot) t[r] !== void 0 && (s[r] = t[r])
      return new z(s)
    }
    constructor(t) {
      ;(t.mode === 'navigate' && (t.mode = 'same-origin'), (this._requestData = t))
    }
    toObject() {
      let t = Object.assign({}, this._requestData)
      return (
        (t.headers = Object.assign({}, this._requestData.headers)),
        t.body && (t.body = t.body.slice(0)),
        t
      )
    }
    toRequest() {
      return new Request(this._requestData.url, this._requestData)
    }
    clone() {
      return new z(this.toObject())
    }
  },
  ge = 'serwist-background-sync',
  it = 1440 * 7,
  Q = new Set(),
  me = (e) => {
    let t = {request: new Y(e.requestData).toRequest(), timestamp: e.timestamp}
    return (e.metadata && (t.metadata = e.metadata), t)
  },
  Ee = class {
    _name
    _onSync
    _maxRetentionTime
    _queueStore
    _forceSyncFallback
    _syncInProgress = !1
    _requestsAddedDuringSync = !1
    constructor(e, {forceSyncFallback: t, onSync: s, maxRetentionTime: r} = {}) {
      if (Q.has(e)) throw new u('duplicate-queue-name', {name: e})
      ;(Q.add(e),
        (this._name = e),
        (this._onSync = s || this.replayRequests),
        (this._maxRetentionTime = r || it),
        (this._forceSyncFallback = !!t),
        (this._queueStore = new Ne(this._name)),
        this._addSyncListener())
    }
    get name() {
      return this._name
    }
    async pushRequest(e) {
      await this._addRequest(e, 'push')
    }
    async unshiftRequest(e) {
      await this._addRequest(e, 'unshift')
    }
    async popRequest() {
      return this._removeRequest('pop')
    }
    async shiftRequest() {
      return this._removeRequest('shift')
    }
    async getAll() {
      let e = await this._queueStore.getAll(),
        t = Date.now(),
        s = []
      for (let r of e) {
        let a = this._maxRetentionTime * 60 * 1e3
        t - r.timestamp > a ? await this._queueStore.deleteEntry(r.id) : s.push(me(r))
      }
      return s
    }
    async size() {
      return await this._queueStore.size()
    }
    async _addRequest({request: e, metadata: t, timestamp: s = Date.now()}, r) {
      let a = {requestData: (await Y.fromRequest(e.clone())).toObject(), timestamp: s}
      switch ((t && (a.metadata = t), r)) {
        case 'push':
          await this._queueStore.pushEntry(a)
          break
        case 'unshift':
          await this._queueStore.unshiftEntry(a)
          break
      }
      this._syncInProgress ? (this._requestsAddedDuringSync = !0) : await this.registerSync()
    }
    async _removeRequest(e) {
      let t = Date.now(),
        s
      switch (e) {
        case 'pop':
          s = await this._queueStore.popEntry()
          break
        case 'shift':
          s = await this._queueStore.shiftEntry()
          break
      }
      if (s) {
        let r = this._maxRetentionTime * 60 * 1e3
        return t - s.timestamp > r ? this._removeRequest(e) : me(s)
      }
    }
    async replayRequests() {
      let e
      for (; (e = await this.shiftRequest());)
        try {
          await fetch(e.request.clone())
        } catch {
          throw (await this.unshiftRequest(e), new u('queue-replay-failed', {name: this._name}))
        }
    }
    async registerSync() {
      if ('sync' in self.registration && !this._forceSyncFallback)
        try {
          await self.registration.sync.register(`${ge}:${this._name}`)
        } catch {}
    }
    _addSyncListener() {
      'sync' in self.registration && !this._forceSyncFallback
        ? self.addEventListener('sync', (e) => {
            if (e.tag === `${ge}:${this._name}`) {
              let t = async () => {
                this._syncInProgress = !0
                let s
                try {
                  await this._onSync({queue: this})
                } catch (r) {
                  if (r instanceof Error) throw ((s = r), s)
                } finally {
                  ;(this._requestsAddedDuringSync &&
                    !(s && !e.lastChance) &&
                    (await this.registerSync()),
                    (this._syncInProgress = !1),
                    (this._requestsAddedDuringSync = !1))
                }
              }
              e.waitUntil(t())
            }
          })
        : this._onSync({queue: this})
    }
    static get _queueNames() {
      return Q
    }
  },
  _e = class {
    _queue
    constructor(e, t) {
      this._queue = new Ee(e, t)
    }
    async fetchDidFail({request: e}) {
      await this._queue.pushRequest({request: e})
    }
  },
  J = {cacheWillUpdate: async ({response: e}) => (e.status === 200 || e.status === 0 ? e : null)}
function A(e) {
  return typeof e == 'string' ? new Request(e) : e
}
var ve = class {
    event
    request
    url
    params
    _cacheKeys = {}
    _strategy
    _handlerDeferred
    _extendLifetimePromises
    _plugins
    _pluginStateMap
    constructor(e, t) {
      ;((this.event = t.event),
        (this.request = t.request),
        t.url && ((this.url = t.url), (this.params = t.params)),
        (this._strategy = e),
        (this._handlerDeferred = new se()),
        (this._extendLifetimePromises = []),
        (this._plugins = [...e.plugins]),
        (this._pluginStateMap = new Map()))
      for (let s of this._plugins) this._pluginStateMap.set(s, {})
      this.event.waitUntil(this._handlerDeferred.promise)
    }
    async fetch(e) {
      let {event: t} = this,
        s = A(e),
        r = await this.getPreloadResponse()
      if (r) return r
      let a = this.hasCallback('fetchDidFail') ? s.clone() : null
      try {
        for (let o of this.iterateCallbacks('requestWillFetch'))
          s = await o({request: s.clone(), event: t})
      } catch (o) {
        if (o instanceof Error)
          throw new u('plugin-error-request-will-fetch', {thrownErrorMessage: o.message})
      }
      let n = s.clone()
      try {
        let o
        o = await fetch(s, s.mode === 'navigate' ? void 0 : this._strategy.fetchOptions)
        for (let i of this.iterateCallbacks('fetchDidSucceed'))
          o = await i({event: t, request: n, response: o})
        return o
      } catch (o) {
        throw (
          a &&
            (await this.runCallbacks('fetchDidFail', {
              error: o,
              event: t,
              originalRequest: a.clone(),
              request: n.clone(),
            })),
          o
        )
      }
    }
    async fetchAndCachePut(e) {
      let t = await this.fetch(e),
        s = t.clone()
      return (this.waitUntil(this.cachePut(e, s)), t)
    }
    async cacheMatch(e) {
      let t = A(e),
        s,
        {cacheName: r, matchOptions: a} = this._strategy,
        n = await this.getCacheKey(t, 'read'),
        o = {...a, cacheName: r}
      s = await caches.match(n, o)
      for (let i of this.iterateCallbacks('cachedResponseWillBeUsed'))
        s =
          (await i({
            cacheName: r,
            matchOptions: a,
            cachedResponse: s,
            request: n,
            event: this.event,
          })) || void 0
      return s
    }
    async cachePut(e, t) {
      let s = A(e)
      await x(0)
      let r = await this.getCacheKey(s, 'write')
      if (!t) throw new u('cache-put-with-no-response', {url: ee(r.url)})
      let a = await this._ensureResponseSafeToCache(t)
      if (!a) return !1
      let {cacheName: n, matchOptions: o} = this._strategy,
        i = await self.caches.open(n),
        c = this.hasCallback('cacheDidUpdate'),
        l = c ? await te(i, r.clone(), ['__WB_REVISION__'], o) : null
      try {
        await i.put(r, c ? a.clone() : a)
      } catch (h) {
        if (h instanceof Error) throw (h.name === 'QuotaExceededError' && (await re()), h)
      }
      for (let h of this.iterateCallbacks('cacheDidUpdate'))
        await h({
          cacheName: n,
          oldResponse: l,
          newResponse: a.clone(),
          request: r,
          event: this.event,
        })
      return !0
    }
    async getCacheKey(e, t) {
      let s = `${e.url} | ${t}`
      if (!this._cacheKeys[s]) {
        let r = e
        for (let a of this.iterateCallbacks('cacheKeyWillBeUsed'))
          r = A(await a({mode: t, request: r, event: this.event, params: this.params}))
        this._cacheKeys[s] = r
      }
      return this._cacheKeys[s]
    }
    hasCallback(e) {
      for (let t of this._strategy.plugins) if (e in t) return !0
      return !1
    }
    async runCallbacks(e, t) {
      for (let s of this.iterateCallbacks(e)) await s(t)
    }
    *iterateCallbacks(e) {
      for (let t of this._strategy.plugins)
        if (typeof t[e] == 'function') {
          let s = this._pluginStateMap.get(t)
          yield (a) => {
            let n = {...a, state: s}
            return t[e](n)
          }
        }
    }
    waitUntil(e) {
      return (this._extendLifetimePromises.push(e), e)
    }
    async doneWaiting() {
      let e
      for (; (e = this._extendLifetimePromises.shift());) await e
    }
    destroy() {
      this._handlerDeferred.resolve(null)
    }
    async getPreloadResponse() {
      if (
        this.event instanceof FetchEvent &&
        this.event.request.mode === 'navigate' &&
        'preloadResponse' in this.event
      )
        try {
          let e = await this.event.preloadResponse
          if (e) return e
        } catch {
          return
        }
    }
    async _ensureResponseSafeToCache(e) {
      let t = e,
        s = !1
      for (let r of this.iterateCallbacks('cacheWillUpdate'))
        if (
          ((t = (await r({request: this.request, response: t, event: this.event})) || void 0),
          (s = !0),
          !t)
        )
          break
      return (s || (t && t.status !== 200 && (t = void 0)), t)
    }
  },
  v = class {
    cacheName
    plugins
    fetchOptions
    matchOptions
    constructor(e = {}) {
      ;((this.cacheName = m.getRuntimeName(e.cacheName)),
        (this.plugins = e.plugins || []),
        (this.fetchOptions = e.fetchOptions),
        (this.matchOptions = e.matchOptions))
    }
    handle(e) {
      let [t] = this.handleAll(e)
      return t
    }
    handleAll(e) {
      e instanceof FetchEvent && (e = {event: e, request: e.request})
      let t = e.event,
        s = typeof e.request == 'string' ? new Request(e.request) : e.request,
        r = new ve(
          this,
          e.url ? {event: t, request: s, url: e.url, params: e.params} : {event: t, request: s},
        ),
        a = this._getResponse(r, s, t)
      return [a, this._awaitComplete(a, r, s, t)]
    }
    async _getResponse(e, t, s) {
      await e.runCallbacks('handlerWillStart', {event: s, request: t})
      let r
      try {
        if (((r = await this._handle(t, e)), r === void 0 || r.type === 'error'))
          throw new u('no-response', {url: t.url})
      } catch (a) {
        if (a instanceof Error) {
          for (let n of e.iterateCallbacks('handlerDidError'))
            if (((r = await n({error: a, event: s, request: t})), r !== void 0)) break
        }
        if (!r) throw a
      }
      for (let a of e.iterateCallbacks('handlerWillRespond'))
        r = await a({event: s, request: t, response: r})
      return r
    }
    async _awaitComplete(e, t, s, r) {
      let a, n
      try {
        a = await e
      } catch {}
      try {
        ;(await t.runCallbacks('handlerDidRespond', {event: r, request: s, response: a}),
          await t.doneWaiting())
      } catch (o) {
        o instanceof Error && (n = o)
      }
      if (
        (await t.runCallbacks('handlerDidComplete', {event: r, request: s, response: a, error: n}),
        t.destroy(),
        n)
      )
        throw n
    }
  }
var b = class extends v {
    _networkTimeoutSeconds
    constructor(e = {}) {
      ;(super(e),
        this.plugins.some((t) => 'cacheWillUpdate' in t) || this.plugins.unshift(J),
        (this._networkTimeoutSeconds = e.networkTimeoutSeconds || 0))
    }
    async _handle(e, t) {
      let s = [],
        r = [],
        a
      if (this._networkTimeoutSeconds) {
        let {id: i, promise: c} = this._getTimeoutPromise({request: e, logs: s, handler: t})
        ;((a = i), r.push(c))
      }
      let n = this._getNetworkPromise({timeoutId: a, request: e, logs: s, handler: t})
      r.push(n)
      let o = await t.waitUntil((async () => (await t.waitUntil(Promise.race(r))) || (await n))())
      if (!o) throw new u('no-response', {url: e.url})
      return o
    }
    _getTimeoutPromise({request: e, logs: t, handler: s}) {
      let r
      return {
        promise: new Promise((a) => {
          r = setTimeout(async () => {
            a(await s.cacheMatch(e))
          }, this._networkTimeoutSeconds * 1e3)
        }),
        id: r,
      }
    }
    async _getNetworkPromise({timeoutId: e, request: t, logs: s, handler: r}) {
      let a, n
      try {
        n = await r.fetchAndCachePut(t)
      } catch (o) {
        o instanceof Error && (a = o)
      }
      return (e && clearTimeout(e), (a || !n) && (n = await r.cacheMatch(t)), n)
    }
  },
  be = class extends v {
    _networkTimeoutSeconds
    constructor(e = {}) {
      ;(super(e), (this._networkTimeoutSeconds = e.networkTimeoutSeconds || 0))
    }
    async _handle(e, t) {
      let s, r
      try {
        let a = [t.fetch(e)]
        if (this._networkTimeoutSeconds) {
          let n = x(this._networkTimeoutSeconds * 1e3)
          a.push(n)
        }
        if (((r = await Promise.race(a)), !r))
          throw new Error(
            `Timed out the network response after ${this._networkTimeoutSeconds} seconds.`,
          )
      } catch (a) {
        a instanceof Error && (s = a)
      }
      if (!r) throw new u('no-response', {url: e.url, error: s})
      return r
    }
  }
var q = (e) => (e && typeof e == 'object' ? e : {handle: e}),
  d = class {
    handler
    match
    method
    catchHandler
    constructor(e, t, s = 'GET') {
      ;((this.handler = q(t)), (this.match = e), (this.method = s))
    }
    setCatchHandler(e) {
      this.catchHandler = q(e)
    }
  },
  Re = class S extends v {
    _fallbackToNetwork
    static defaultPrecacheCacheabilityPlugin = {
      async cacheWillUpdate({response: t}) {
        return !t || t.status >= 400 ? null : t
      },
    }
    static copyRedirectedCacheableResponsesPlugin = {
      async cacheWillUpdate({response: t}) {
        return t.redirected ? await we(t) : t
      },
    }
    constructor(t = {}) {
      ;((t.cacheName = m.getPrecacheName(t.cacheName)),
        super(t),
        (this._fallbackToNetwork = t.fallbackToNetwork !== !1),
        this.plugins.push(S.copyRedirectedCacheableResponsesPlugin))
    }
    async _handle(t, s) {
      let r = await s.getPreloadResponse()
      if (r) return r
      let a = await s.cacheMatch(t)
      return (
        a ||
        (s.event && s.event.type === 'install'
          ? await this._handleInstall(t, s)
          : await this._handleFetch(t, s))
      )
    }
    async _handleFetch(t, s) {
      let r,
        a = s.params || {}
      if (this._fallbackToNetwork) {
        let n = a.integrity,
          o = t.integrity,
          i = !o || o === n
        if (
          ((r = await s.fetch(new Request(t, {integrity: t.mode !== 'no-cors' ? o || n : void 0}))),
          n && i && t.mode !== 'no-cors')
        ) {
          this._useDefaultCacheabilityPluginIfNeeded()
          let c = await s.cachePut(t, r.clone())
        }
      } else throw new u('missing-precache-entry', {cacheName: this.cacheName, url: t.url})
      return r
    }
    async _handleInstall(t, s) {
      this._useDefaultCacheabilityPluginIfNeeded()
      let r = await s.fetch(t)
      if (!(await s.cachePut(t, r.clone())))
        throw new u('bad-precaching-response', {url: t.url, status: r.status})
      return r
    }
    _useDefaultCacheabilityPluginIfNeeded() {
      let t = null,
        s = 0
      for (let [r, a] of this.plugins.entries())
        a !== S.copyRedirectedCacheableResponsesPlugin &&
          (a === S.defaultPrecacheCacheabilityPlugin && (t = r), a.cacheWillUpdate && s++)
      s === 0
        ? this.plugins.push(S.defaultPrecacheCacheabilityPlugin)
        : s > 1 && t !== null && this.plugins.splice(t, 1)
    }
  },
  xe = class extends d {
    _allowlist
    _denylist
    constructor(e, {allowlist: t = [/./], denylist: s = []} = {}) {
      ;(super((r) => this._match(r), e), (this._allowlist = t), (this._denylist = s))
    }
    _match({url: e, request: t}) {
      if (t && t.mode !== 'navigate') return !1
      let s = e.pathname + e.search
      for (let r of this._denylist) if (r.test(s)) return !1
      return !!this._allowlist.some((r) => r.test(s))
    }
  },
  De = () => !!self.registration?.navigationPreload,
  Se = (e) => {
    De() &&
      self.addEventListener('activate', (t) => {
        t.waitUntil(
          self.registration.navigationPreload.enable().then(() => {
            e && self.registration.navigationPreload.setHeaderValue(e)
          }),
        )
      })
  }
var ct = (e, t = []) => {
  for (let s of [...e.searchParams.keys()]) t.some((r) => r.test(s)) && e.searchParams.delete(s)
  return e
}
function* qe(
  e,
  {
    directoryIndex: t = 'index.html',
    ignoreURLParametersMatching: s = [/^utm_/, /^fbclid$/],
    cleanURLs: r = !0,
    urlManipulation: a,
  } = {},
) {
  let n = new URL(e, location.href)
  ;((n.hash = ''), yield n.href)
  let o = ct(n, s)
  if ((yield o.href, t && o.pathname.endsWith('/'))) {
    let i = new URL(o.href)
    ;((i.pathname += t), yield i.href)
  }
  if (r) {
    let i = new URL(o.href)
    ;((i.pathname += '.html'), yield i.href)
  }
  if (a) {
    let i = a({url: n})
    for (let c of i) yield c.href
  }
}
var Ce = class extends d {
    constructor(e, t, s) {
      let r = ({url: a}) => {
        let n = e.exec(a.href)
        if (n && !(a.origin !== location.origin && n.index !== 0)) return n.slice(1)
      }
      super(r, t, s)
    }
  },
  Te = (e) => {
    m.updateDetails(e)
  },
  lt = '__WB_REVISION__',
  ke = (e) => {
    if (!e) throw new u('add-to-cache-list-unexpected-type', {entry: e})
    if (typeof e == 'string') {
      let n = new URL(e, location.href)
      return {cacheKey: n.href, url: n.href}
    }
    let {revision: t, url: s} = e
    if (!s) throw new u('add-to-cache-list-unexpected-type', {entry: e})
    if (!t) {
      let n = new URL(s, location.href)
      return {cacheKey: n.href, url: n.href}
    }
    let r = new URL(s, location.href),
      a = new URL(s, location.href)
    return (r.searchParams.set(lt, t), {cacheKey: r.href, url: a.href})
  },
  Oe = class {
    updatedURLs = []
    notUpdatedURLs = []
    handlerWillStart = async ({request: e, state: t}) => {
      t && (t.originalRequest = e)
    }
    cachedResponseWillBeUsed = async ({event: e, state: t, cachedResponse: s}) => {
      if (e.type === 'install' && t?.originalRequest && t.originalRequest instanceof Request) {
        let r = t.originalRequest.url
        s ? this.notUpdatedURLs.push(r) : this.updatedURLs.push(r)
      }
      return s
    }
  },
  Ae = (e, t, s) => {
    if (typeof e == 'string') {
      let r = new URL(e, location.href),
        a = ({url: n}) => n.href === r.href
      return new d(a, t, s)
    }
    if (e instanceof RegExp) return new Ce(e, t, s)
    if (typeof e == 'function') return new d(e, t, s)
    if (e instanceof d) return e
    throw new u('unsupported-route-type', {
      moduleName: 'serwist',
      funcName: 'parseRoute',
      paramName: 'capture',
    })
  }
var Pe = async (e, t, s) => {
  let r = t.map((o, i) => ({index: i, item: o})),
    a = async (o) => {
      let i = []
      for (;;) {
        let c = r.pop()
        if (!c) return o(i)
        let l = await s(c.item)
        i.push({result: l, index: c.index})
      }
    },
    n = Array.from({length: e}, () => new Promise(a))
  return (await Promise.all(n))
    .flat()
    .sort((o, i) => (o.index < i.index ? -1 : 1))
    .map((o) => o.result)
}
var ws = typeof navigator < 'u' && /^((?!chrome|android).)*safari/i.test(navigator.userAgent)
var ut = class {
    _statuses
    _headers
    constructor(e = {}) {
      ;((this._statuses = e.statuses), e.headers && (this._headers = new Headers(e.headers)))
    }
    isResponseCacheable(e) {
      let t = !0
      if ((this._statuses && (t = this._statuses.includes(e.status)), this._headers && t)) {
        for (let [s, r] of this._headers.entries())
          if (e.headers.get(s) !== r) {
            t = !1
            break
          }
      }
      return t
    }
  },
  C = class {
    _cacheableResponse
    constructor(e) {
      this._cacheableResponse = new ut(e)
    }
    cacheWillUpdate = async ({response: e}) =>
      this._cacheableResponse.isResponseCacheable(e) ? e : null
  },
  ht = 'serwist-expiration',
  P = 'cache-entries',
  Ue = (e) => {
    let t = new URL(e, location.href)
    return ((t.hash = ''), t.href)
  },
  dt = class {
    _cacheName
    _db = null
    constructor(e) {
      this._cacheName = e
    }
    _getId(e) {
      return `${this._cacheName}|${Ue(e)}`
    }
    _upgradeDb(e) {
      let t = e.createObjectStore(P, {keyPath: 'id'})
      ;(t.createIndex('cacheName', 'cacheName', {unique: !1}),
        t.createIndex('timestamp', 'timestamp', {unique: !1}))
    }
    _upgradeDbAndDeleteOldDbs(e) {
      ;(this._upgradeDb(e), this._cacheName && de(this._cacheName))
    }
    async setTimestamp(e, t) {
      e = Ue(e)
      let s = {id: this._getId(e), cacheName: this._cacheName, url: e, timestamp: t},
        r = (await this.getDb()).transaction(P, 'readwrite', {durability: 'relaxed'})
      ;(await r.store.put(s), await r.done)
    }
    async getTimestamp(e) {
      return (await (await this.getDb()).get(P, this._getId(e)))?.timestamp
    }
    async expireEntries(e, t) {
      let s = await (
          await this.getDb()
        )
          .transaction(P, 'readwrite')
          .store.index('timestamp')
          .openCursor(null, 'prev'),
        r = [],
        a = 0
      for (; s;) {
        let n = s.value
        ;(n.cacheName === this._cacheName &&
          ((e && n.timestamp < e) || (t && a >= t) ? (s.delete(), r.push(n.url)) : a++),
          (s = await s.continue()))
      }
      return r
    }
    async getDb() {
      return (
        this._db ||
          (this._db = await O(ht, 1, {upgrade: this._upgradeDbAndDeleteOldDbs.bind(this)})),
        this._db
      )
    }
  },
  pt = class {
    _isRunning = !1
    _rerunRequested = !1
    _maxEntries
    _maxAgeSeconds
    _matchOptions
    _cacheName
    _timestampModel
    constructor(e, t = {}) {
      ;((this._maxEntries = t.maxEntries),
        (this._maxAgeSeconds = t.maxAgeSeconds),
        (this._matchOptions = t.matchOptions),
        (this._cacheName = e),
        (this._timestampModel = new dt(e)))
    }
    async expireEntries() {
      if (this._isRunning) {
        this._rerunRequested = !0
        return
      }
      this._isRunning = !0
      let e = this._maxAgeSeconds ? Date.now() - this._maxAgeSeconds * 1e3 : 0,
        t = await this._timestampModel.expireEntries(e, this._maxEntries),
        s = await self.caches.open(this._cacheName)
      for (let r of t) await s.delete(r, this._matchOptions)
      ;((this._isRunning = !1),
        this._rerunRequested && ((this._rerunRequested = !1), this.expireEntries()))
    }
    async updateTimestamp(e) {
      await this._timestampModel.setTimestamp(e, Date.now())
    }
    async isURLExpired(e) {
      if (!this._maxAgeSeconds) return !1
      let t = await this._timestampModel.getTimestamp(e),
        s = Date.now() - this._maxAgeSeconds * 1e3
      return t !== void 0 ? t < s : !0
    }
    async delete() {
      ;((this._rerunRequested = !1),
        await this._timestampModel.expireEntries(Number.POSITIVE_INFINITY))
    }
  },
  ft = (e) => {
    V.add(e)
  },
  T = class {
    _config
    _cacheExpirations
    constructor(e = {}) {
      ;((this._config = e),
        (this._cacheExpirations = new Map()),
        this._config.maxAgeFrom || (this._config.maxAgeFrom = 'last-fetched'),
        this._config.purgeOnQuotaError && ft(() => this.deleteCacheAndMetadata()))
    }
    _getCacheExpiration(e) {
      if (e === m.getRuntimeName()) throw new u('expire-custom-caches-only')
      let t = this._cacheExpirations.get(e)
      return (t || ((t = new pt(e, this._config)), this._cacheExpirations.set(e, t)), t)
    }
    cachedResponseWillBeUsed({event: e, cacheName: t, request: s, cachedResponse: r}) {
      if (!r) return null
      let a = this._isResponseDateFresh(r),
        n = this._getCacheExpiration(t),
        o = this._config.maxAgeFrom === 'last-used',
        i = (async () => {
          ;(o && (await n.updateTimestamp(s.url)), await n.expireEntries())
        })()
      try {
        e.waitUntil(i)
      } catch {}
      return a ? r : null
    }
    _isResponseDateFresh(e) {
      if (this._config.maxAgeFrom === 'last-used') return !0
      let t = Date.now()
      if (!this._config.maxAgeSeconds) return !0
      let s = this._getDateHeaderTimestamp(e)
      return s === null ? !0 : s >= t - this._config.maxAgeSeconds * 1e3
    }
    _getDateHeaderTimestamp(e) {
      if (!e.headers.has('date')) return null
      let t = e.headers.get('date'),
        s = new Date(t).getTime()
      return Number.isNaN(s) ? null : s
    }
    async cacheDidUpdate({cacheName: e, request: t}) {
      let s = this._getCacheExpiration(e)
      ;(await s.updateTimestamp(t.url), await s.expireEntries())
    }
    async deleteCacheAndMetadata() {
      for (let [e, t] of this._cacheExpirations) (await self.caches.delete(e), await t.delete())
      this._cacheExpirations = new Map()
    }
  },
  gt = 'serwist-google-analytics',
  mt = 2880,
  wt = /^\/(\w+\/)?collect/,
  yt =
    (e) =>
    async ({queue: t}) => {
      let s
      for (; (s = await t.shiftRequest());) {
        let {request: r, timestamp: a} = s,
          n = new URL(r.url)
        try {
          let o =
              r.method === 'POST' ? new URLSearchParams(await r.clone().text()) : n.searchParams,
            i = a - (Number(o.get('qt')) || 0),
            c = Date.now() - i
          if ((o.set('qt', String(c)), e.parameterOverrides))
            for (let l of Object.keys(e.parameterOverrides)) {
              let h = e.parameterOverrides[l]
              o.set(l, h)
            }
          ;(typeof e.hitFilter == 'function' && e.hitFilter.call(null, o),
            await fetch(
              new Request(n.origin + n.pathname, {
                body: o.toString(),
                method: 'POST',
                mode: 'cors',
                credentials: 'omit',
                headers: {'Content-Type': 'text/plain'},
              }),
            ))
        } catch (o) {
          throw (await t.unshiftRequest(s), o)
        }
      }
    },
  Nt = (e) => {
    let t = ({url: r}) => r.hostname === 'www.google-analytics.com' && wt.test(r.pathname),
      s = new be({plugins: [e]})
    return [new d(t, s, 'GET'), new d(t, s, 'POST')]
  },
  Et = (e) => {
    let t = ({url: s}) =>
      s.hostname === 'www.google-analytics.com' && s.pathname === '/analytics.js'
    return new d(t, new b({cacheName: e}), 'GET')
  },
  _t = (e) => {
    let t = ({url: s}) => s.hostname === 'www.googletagmanager.com' && s.pathname === '/gtag/js'
    return new d(t, new b({cacheName: e}), 'GET')
  },
  vt = (e) => {
    let t = ({url: s}) => s.hostname === 'www.googletagmanager.com' && s.pathname === '/gtm.js'
    return new d(t, new b({cacheName: e}), 'GET')
  },
  $e = ({serwist: e, cacheName: t, ...s}) => {
    let r = m.getGoogleAnalyticsName(t),
      a = new _e(gt, {maxRetentionTime: mt, onSync: yt(s)}),
      n = [vt(r), Et(r), _t(r), ...Nt(a)]
    for (let o of n) e.registerRoute(o)
  },
  bt = class {
    _fallbackUrls
    _serwist
    constructor({fallbackUrls: e, serwist: t}) {
      ;((this._fallbackUrls = e), (this._serwist = t))
    }
    async handlerDidError(e) {
      for (let t of this._fallbackUrls)
        if (typeof t == 'string') {
          let s = await this._serwist.matchPrecache(t)
          if (s !== void 0) return s
        } else if (t.matcher(e)) {
          let s = await this._serwist.matchPrecache(t.url)
          if (s !== void 0) return s
        }
    }
  }
var Ie = class extends v {
  async _handle(e, t) {
    let s = [],
      r = await t.cacheMatch(e),
      a
    if (!r)
      try {
        r = await t.fetchAndCachePut(e)
      } catch (n) {
        n instanceof Error && (a = n)
      }
    if (!r) throw new u('no-response', {url: e.url, error: a})
    return r
  }
}
var Le = class extends v {
    constructor(e = {}) {
      ;(super(e), this.plugins.some((t) => 'cacheWillUpdate' in t) || this.plugins.unshift(J))
    }
    async _handle(e, t) {
      let s = [],
        r = t.fetchAndCachePut(e).catch(() => {})
      t.waitUntil(r)
      let a = await t.cacheMatch(e),
        n
      if (!a)
        try {
          a = await r
        } catch (o) {
          o instanceof Error && (n = o)
        }
      if (!a) throw new u('no-response', {url: e.url, error: n})
      return a
    }
  },
  Rt = class extends d {
    constructor(e, t) {
      let s = ({request: r}) => {
        let a = e.getUrlsToPrecacheKeys()
        for (let n of qe(r.url, t)) {
          let o = a.get(n)
          if (o) return {cacheKey: o, integrity: e.getIntegrityForPrecacheKey(o)}
        }
      }
      super(s, e.precacheStrategy)
    }
  },
  xt = class {
    _precacheController
    constructor({precacheController: e}) {
      this._precacheController = e
    }
    cacheKeyWillBeUsed = async ({request: e, params: t}) => {
      let s = t?.cacheKey || this._precacheController.getPrecacheKeyForUrl(e.url)
      return s ? new Request(s, {headers: e.headers}) : e
    }
  },
  Dt = (e, t = {}) => {
    let {
      cacheName: s,
      plugins: r = [],
      fetchOptions: a,
      matchOptions: n,
      fallbackToNetwork: o,
      directoryIndex: i,
      ignoreURLParametersMatching: c,
      cleanURLs: l,
      urlManipulation: h,
      cleanupOutdatedCaches: f,
      concurrency: _ = 10,
      navigateFallback: $,
      navigateFallbackAllowlist: y,
      navigateFallbackDenylist: p,
    } = t ?? {}
    return {
      precacheStrategyOptions: {
        cacheName: m.getPrecacheName(s),
        plugins: [...r, new xt({precacheController: e})],
        fetchOptions: a,
        matchOptions: n,
        fallbackToNetwork: o,
      },
      precacheRouteOptions: {
        directoryIndex: i,
        ignoreURLParametersMatching: c,
        cleanURLs: l,
        urlManipulation: h,
      },
      precacheMiscOptions: {
        cleanupOutdatedCaches: f,
        concurrency: _,
        navigateFallback: $,
        navigateFallbackAllowlist: y,
        navigateFallbackDenylist: p,
      },
    }
  },
  Ve = class {
    _urlsToCacheKeys = new Map()
    _urlsToCacheModes = new Map()
    _cacheKeysToIntegrities = new Map()
    _concurrentPrecaching
    _precacheStrategy
    _routes
    _defaultHandlerMap
    _catchHandler
    _requestRules
    constructor({
      precacheEntries: e,
      precacheOptions: t,
      skipWaiting: s = !1,
      importScripts: r,
      navigationPreload: a = !1,
      cacheId: n,
      clientsClaim: o = !1,
      runtimeCaching: i,
      offlineAnalyticsConfig: c,
      disableDevLogs: l = !1,
      fallbacks: h,
      requestRules: f,
    } = {}) {
      let {
        precacheStrategyOptions: _,
        precacheRouteOptions: $,
        precacheMiscOptions: y,
      } = Dt(this, t)
      if (
        ((this._concurrentPrecaching = y.concurrency),
        (this._precacheStrategy = new Re(_)),
        (this._routes = new Map()),
        (this._defaultHandlerMap = new Map()),
        (this._requestRules = f),
        (this.handleInstall = this.handleInstall.bind(this)),
        (this.handleActivate = this.handleActivate.bind(this)),
        (this.handleFetch = this.handleFetch.bind(this)),
        (this.handleCache = this.handleCache.bind(this)),
        r && r.length > 0 && self.importScripts(...r),
        a && Se(),
        n !== void 0 && Te({prefix: n}),
        s
          ? self.skipWaiting()
          : self.addEventListener('message', (p) => {
              p.data && p.data.type === 'SKIP_WAITING' && self.skipWaiting()
            }),
        o && ne(),
        e && e.length > 0 && this.addToPrecacheList(e),
        y.cleanupOutdatedCaches && ae(_.cacheName),
        this.registerRoute(new Rt(this, $)),
        y.navigateFallback &&
          this.registerRoute(
            new xe(this.createHandlerBoundToUrl(y.navigateFallback), {
              allowlist: y.navigateFallbackAllowlist,
              denylist: y.navigateFallbackDenylist,
            }),
          ),
        c !== void 0 &&
          (typeof c == 'boolean' ? c && $e({serwist: this}) : $e({...c, serwist: this})),
        i !== void 0)
      ) {
        if (h !== void 0) {
          let p = new bt({fallbackUrls: h.entries, serwist: this})
          i.forEach((I) => {
            I.handler instanceof v &&
              !I.handler.plugins.some((Fe) => 'handlerDidError' in Fe) &&
              I.handler.plugins.push(p)
          })
        }
        for (let p of i) this.registerCapture(p.matcher, p.handler, p.method)
      }
      l && ye()
    }
    get precacheStrategy() {
      return this._precacheStrategy
    }
    get routes() {
      return this._routes
    }
    addEventListeners() {
      ;(self.addEventListener('install', this.handleInstall),
        self.addEventListener('activate', this.handleActivate),
        self.addEventListener('fetch', this.handleFetch),
        self.addEventListener('message', this.handleCache))
    }
    addToPrecacheList(e) {
      let t = []
      for (let s of e) {
        typeof s == 'string'
          ? t.push(s)
          : s && !s.integrity && s.revision === void 0 && t.push(s.url)
        let {cacheKey: r, url: a} = ke(s),
          n = typeof s != 'string' && s.revision ? 'reload' : 'default'
        if (this._urlsToCacheKeys.has(a) && this._urlsToCacheKeys.get(a) !== r)
          throw new u('add-to-cache-list-conflicting-entries', {
            firstEntry: this._urlsToCacheKeys.get(a),
            secondEntry: r,
          })
        if (typeof s != 'string' && s.integrity) {
          if (
            this._cacheKeysToIntegrities.has(r) &&
            this._cacheKeysToIntegrities.get(r) !== s.integrity
          )
            throw new u('add-to-cache-list-conflicting-integrities', {url: a})
          this._cacheKeysToIntegrities.set(r, s.integrity)
        }
        ;(this._urlsToCacheKeys.set(a, r), this._urlsToCacheModes.set(a, n))
      }
      if (t.length > 0) {
        let s = `Serwist is precaching URLs without revision info: ${t.join(', ')}
This is generally NOT safe. Learn more at https://bit.ly/wb-precache`
        console.warn(s)
      }
    }
    handleInstall(e) {
      return (
        this.registerRequestRules(e),
        F(e, async () => {
          let t = new Oe()
          ;(this.precacheStrategy.plugins.push(t),
            await Pe(
              this._concurrentPrecaching,
              Array.from(this._urlsToCacheKeys.entries()),
              async ([a, n]) => {
                let o = this._cacheKeysToIntegrities.get(n),
                  i = this._urlsToCacheModes.get(a),
                  c = new Request(a, {integrity: o, cache: i, credentials: 'same-origin'})
                await Promise.all(
                  this.precacheStrategy.handleAll({
                    event: e,
                    request: c,
                    url: new URL(c.url),
                    params: {cacheKey: n},
                  }),
                )
              },
            ))
          let {updatedURLs: s, notUpdatedURLs: r} = t
          return {updatedURLs: s, notUpdatedURLs: r}
        })
      )
    }
    async registerRequestRules(e) {
      if (this._requestRules && e?.addRoutes)
        try {
          ;(await e.addRoutes(this._requestRules), (this._requestRules = void 0))
        } catch (t) {
          throw t
        }
    }
    handleActivate(e) {
      return F(e, async () => {
        let t = await self.caches.open(this.precacheStrategy.cacheName),
          s = await t.keys(),
          r = new Set(this._urlsToCacheKeys.values()),
          a = []
        for (let n of s) r.has(n.url) || (await t.delete(n), a.push(n.url))
        return {deletedCacheRequests: a}
      })
    }
    handleFetch(e) {
      let {request: t} = e,
        s = this.handleRequest({request: t, event: e})
      s && e.respondWith(s)
    }
    handleCache(e) {
      if (e.data && e.data.type === 'CACHE_URLS') {
        let {payload: t} = e.data,
          s = Promise.all(
            t.urlsToCache.map((r) => {
              let a
              return (
                typeof r == 'string' ? (a = new Request(r)) : (a = new Request(...r)),
                this.handleRequest({request: a, event: e})
              )
            }),
          )
        ;(e.waitUntil(s), e.ports?.[0] && s.then(() => e.ports[0].postMessage(!0)))
      }
    }
    setDefaultHandler(e, t = 'GET') {
      this._defaultHandlerMap.set(t, q(e))
    }
    setCatchHandler(e) {
      this._catchHandler = q(e)
    }
    registerCapture(e, t, s) {
      let r = Ae(e, t, s)
      return (this.registerRoute(r), r)
    }
    registerRoute(e) {
      ;(this._routes.has(e.method) || this._routes.set(e.method, []),
        this._routes.get(e.method).push(e))
    }
    unregisterRoute(e) {
      if (!this._routes.has(e.method))
        throw new u('unregister-route-but-not-found-with-method', {method: e.method})
      let t = this._routes.get(e.method).indexOf(e)
      if (t > -1) this._routes.get(e.method).splice(t, 1)
      else throw new u('unregister-route-route-not-registered')
    }
    getUrlsToPrecacheKeys() {
      return this._urlsToCacheKeys
    }
    getPrecachedUrls() {
      return [...this._urlsToCacheKeys.keys()]
    }
    getPrecacheKeyForUrl(e) {
      let t = new URL(e, location.href)
      return this._urlsToCacheKeys.get(t.href)
    }
    getIntegrityForPrecacheKey(e) {
      return this._cacheKeysToIntegrities.get(e)
    }
    async matchPrecache(e) {
      let t = e instanceof Request ? e.url : e,
        s = this.getPrecacheKeyForUrl(t)
      if (s) return (await self.caches.open(this.precacheStrategy.cacheName)).match(s)
    }
    createHandlerBoundToUrl(e) {
      let t = this.getPrecacheKeyForUrl(e)
      if (!t) throw new u('non-precached-url', {url: e})
      return (s) => (
        (s.request = new Request(e)),
        (s.params = {cacheKey: t, ...s.params}),
        this.precacheStrategy.handle(s)
      )
    }
    handleRequest({request: e, event: t}) {
      let s = new URL(e.url, location.href)
      if (!s.protocol.startsWith('http')) return
      let r = s.origin === location.origin,
        {params: a, route: n} = this.findMatchingRoute({
          event: t,
          request: e,
          sameOrigin: r,
          url: s,
        }),
        o = n?.handler,
        i = [],
        c = e.method
      if ((!o && this._defaultHandlerMap.has(c) && (o = this._defaultHandlerMap.get(c)), !o)) return
      let l
      try {
        l = o.handle({url: s, request: e, event: t, params: a})
      } catch (f) {
        l = Promise.reject(f)
      }
      let h = n?.catchHandler
      return (
        l instanceof Promise &&
          (this._catchHandler || h) &&
          (l = l.catch(async (f) => {
            if (h)
              try {
                return await h.handle({url: s, request: e, event: t, params: a})
              } catch (_) {
                _ instanceof Error && (f = _)
              }
            if (this._catchHandler) return this._catchHandler.handle({url: s, request: e, event: t})
            throw f
          })),
        l
      )
    }
    findMatchingRoute({url: e, sameOrigin: t, request: s, event: r}) {
      let a = this._routes.get(s.method) || []
      for (let n of a) {
        let o,
          i = n.match({url: e, sameOrigin: t, request: s, event: r})
        if (i)
          return (
            (o = i),
            ((Array.isArray(o) && o.length === 0) ||
              (i.constructor === Object && Object.keys(i).length === 0) ||
              typeof i == 'boolean') &&
              (o = void 0),
            {route: n, params: o}
          )
      }
      return {}
    }
  }
var U = 3600 * 24,
  St = new Ve({
    precacheEntries: N,
    skipWaiting: !0,
    clientsClaim: !0,
    navigationPreload: !1,
    runtimeCaching: [
      {
        matcher: ({url: e, sameOrigin: t}) =>
          e.hostname === 'cdn.sanity.io' || (t && e.pathname.startsWith('/_next/image')),
        handler: new Le({
          cacheName: 'sanity-images',
          plugins: [new C({statuses: [0, 200]}), new T({maxEntries: 128, maxAgeSeconds: 30 * U})],
        }),
      },
      {
        matcher: ({url: e, sameOrigin: t, request: s}) =>
          t &&
          s.method === 'GET' &&
          !e.pathname.startsWith('/_next/') &&
          /\.(?:png|jpe?g|gif|webp|avif|svg|ico|woff2?)$/i.test(e.pathname),
        handler: new Ie({
          cacheName: 'static-assets',
          plugins: [new C({statuses: [0, 200]}), new T({maxEntries: 64, maxAgeSeconds: 30 * U})],
        }),
      },
      {
        matcher: ({request: e, url: t, sameOrigin: s}) =>
          s && e.headers.get('RSC') === '1' && !t.pathname.startsWith('/api/'),
        handler: new b({
          cacheName: 'rsc-v2',
          networkTimeoutSeconds: 5,
          plugins: [new C({statuses: [0, 200]}), new T({maxEntries: 64, maxAgeSeconds: 1 * U})],
        }),
      },
      {
        matcher: ({request: e, url: t, sameOrigin: s}) =>
          s && e.destination === 'document' && !t.pathname.startsWith('/api/'),
        handler: new b({
          cacheName: 'pages-v2',
          networkTimeoutSeconds: 5,
          plugins: [new C({statuses: [0, 200]}), new T({maxEntries: 64, maxAgeSeconds: 1 * U})],
        }),
      },
    ],
    fallbacks: {
      entries: [{url: '/~offline', matcher: ({request: e}) => e.destination === 'document'}],
    },
  })
St.addEventListeners()
