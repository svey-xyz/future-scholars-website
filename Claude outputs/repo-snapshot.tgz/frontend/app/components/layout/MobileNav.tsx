'use client'

import {useEffect, useState, useSyncExternalStore, type CSSProperties} from 'react'
import {usePathname} from 'next/navigation'
import {stegaClean} from '@sanity/client/stega'
import {ArrowTopRightOnSquareIcon, ChevronDownIcon} from '@heroicons/react/24/outline'

import {Button} from '@/components/ui/button'
import {Separator} from '@/components/ui/separator'
import {Collapsible, CollapsibleContent, CollapsibleTrigger} from '@/components/ui/collapsible'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import ResolvedLink from '@/app/components/common/ResolvedLink'
import FooterContent from './FooterContent'
import {linkResolver} from '@/sanity/lib/utils'
import {cn} from '@/lib/utils'
import type {
  NavItem,
  NavLinkItem,
  SettingsContact,
  SettingsLegal,
  SettingsMobileNav,
} from '@/sanity/lib/types'

// CSS custom property carrier for the per-item stagger cascade.
type CSSVars = CSSProperties & {'--reveal-i'?: number}

type MobileNavProps = {
  navigation: NavItem[]
  mobileNav: SettingsMobileNav
  contact: SettingsContact
  legal: SettingsLegal
  /** Visibility is owned by HeaderNav (inline vs collapsed). */
  className?: string
}

/**
 * Mount-gated to avoid a known Radix Dialog + React 19 hydration mismatch on the
 * SheetTrigger button (see the original MobileMenu note). Rendering only after
 * mount sidesteps it; the trigger is hidden until HeaderNav decides to collapse,
 * so the pre-mount gap is invisible.
 */
const subscribe = () => () => {}

/**
 * Full-screen menu that slides down from behind the fixed header.
 *
 * Stacking: the header is `z-40`; the sheet panel sits at `z-30`, so the
 * header stays visible on top and the hamburger morphs into the X — that X is
 * the menu's close affordance (no in-panel close button, `showClose={false}`).
 *
 * The Sheet is **non-modal** (`modal={false}`) — the Radix pattern for a
 * dialog under persistent, interactive chrome. Radix's `DialogContentNonModal`
 * disables the focus trap and outside-pointer-events lock and skips dismissal
 * when the outside target is the trigger, so the header keeps working while
 * open: the X toggles closed, and the logo/CTA dismiss on pointerdown then
 * navigate on click. Esc still closes; focus returns to the hamburger.
 *
 * The two modal behaviours worth keeping are restored manually while open
 * (see the effect below): a body scroll lock, and `inert` on `main`/`footer`
 * — the regions the panel visually covers — so background content leaves the
 * tab order and a11y tree without (unlike Radix's modal `hideOthers`) taking
 * the header with it. A route-change guard closes the menu after header
 * navigations.
 *
 * The panel pads `pt-24` to clear the header's expanded chrome; its own
 * background runs to the viewport top *behind* the (translucent) header, so
 * the contracted (scrolled) header never shows a seam.
 */
export default function MobileNav({
  navigation,
  mobileNav,
  contact,
  legal,
  className,
}: MobileNavProps) {
  const [open, setOpen] = useState(false)
  const pathname = usePathname()

  const mounted = useSyncExternalStore(
    subscribe,
    () => true,
    () => false,
  )

  const showFooter = Boolean(mobileNav?.showFooterContent)
  const close = () => setOpen(false)

  // Close after route changes (header logo/CTA navigations happen outside the
  // sheet, so no in-panel onClick can catch them). In-panel links also close
  // via onNavigate — needed when the target is the current route. "Adjust
  // state during render" per react.dev/you-might-not-need-an-effect.
  const [prevPathname, setPrevPathname] = useState(pathname)
  if (prevPathname !== pathname) {
    setPrevPathname(pathname)
    if (open) setOpen(false)
  }

  // Non-modal Sheet: restore the two modal behaviours we still want while
  // open. Scroll lock on <body>, and `inert` on the regions the panel covers
  // (main/footer) so their content drops out of the tab order and the a11y
  // tree — the header intentionally stays live.
  useEffect(() => {
    if (!open) return
    const {body} = document
    const prevOverflow = body.style.overflow
    body.style.overflow = 'hidden'
    const covered = Array.from(document.querySelectorAll<HTMLElement>('main, footer'))
    const prevInert = covered.map((el) => el.inert)
    covered.forEach((el) => {
      el.inert = true
    })
    return () => {
      body.style.overflow = prevOverflow
      covered.forEach((el, i) => {
        el.inert = prevInert[i]
      })
    }
  }, [open])

  if (!mounted) {
    // Reserve the slot so layout doesn't shift when the button appears.
    return <div className={cn('h-9 w-9', className)} aria-hidden="true" />
  }

  return (
    <div className={className}>
      <Sheet open={open} onOpenChange={setOpen} modal={false}>
        <SheetTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
          >
            <HamburgerIcon open={open} />
          </Button>
        </SheetTrigger>
        {/* Non-modal Radix Dialog: Esc-to-close and focus-return still apply;
            no overlay is rendered (the opaque panel covers the viewport).
            Full-viewport top-slide: width / height / padding overrides beat
            the top variant via tailwind-merge; z-30 keeps it under the z-40
            header. */}
        <SheetContent
          side="top"
          showClose={false}
          className="inset-x-0 top-0 z-30 flex h-full w-full max-w-none flex-col gap-0 overflow-hidden border-b-0 p-0 pt-24"
        >
          {/* Dialog accessible name/description — visually the header above
              (logo + X) is the menu's chrome, so both stay sr-only. */}
          <SheetTitle className="sr-only">Menu</SheetTitle>
          <SheetDescription className="sr-only">Site navigation links</SheetDescription>

          {/* `overflow-x-hidden` clips the staggered reveal's translateX so it
              can't spawn a flickering horizontal scrollbar (which reflowed the
              header/footer). `overscroll-contain` keeps rubber-banding from
              reaching the locked page behind. */}
          <nav
            aria-label="Mobile"
            className="container flex flex-1 flex-col gap-1 overflow-x-hidden overflow-y-auto overscroll-contain py-6"
          >
            {navigation.map((item, i) =>
              item._type === 'navDropdown' ? (
                <MobileDropdown
                  key={item._key}
                  title={item.title}
                  links={item.links ?? []}
                  pathname={pathname}
                  index={i}
                  onNavigate={close}
                />
              ) : (
                <MobileLeaf
                  key={item._key}
                  link={item}
                  pathname={pathname}
                  index={i}
                  onNavigate={close}
                />
              ),
            )}
          </nav>

          {showFooter && (
            <div className="container shrink-0 pb-8">
              <Separator className="mb-4" />
              <FooterContent contact={contact} legal={legal} compact />
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  )
}

function MobileLeaf({
  link,
  pathname,
  index,
  nested = false,
  onNavigate,
}: {
  link: NavLinkItem
  pathname: string
  index: number
  nested?: boolean
  onNavigate: () => void
}) {
  const href = linkResolver(link.link)
  const label = link.resolvedTitle || link.title || ''
  // `stegaClean`: enum comparison must ignore draft-mode stega characters.
  const isExternal = stegaClean(link.link?.linkType) === 'href'
  const opensInNewTab = Boolean(link.link?.openInNewTab)
  const isActive = !isExternal && typeof href === 'string' && href === pathname

  return (
    // Wrapper carries the per-item stagger cascade for the Sheet reveal
    // (`--reveal-i` drives the cascade declared in globals.css).
    <div className={cn(!nested && 'mobile-nav-item')} style={{'--reveal-i': index} as CSSVars}>
      <ResolvedLink
        link={link.link}
        ariaCurrent={isActive ? 'page' : undefined}
        transitionTypes={isExternal ? undefined : ['nav-forward']}
        onClick={onNavigate}
        className={cn(
          'flex items-center justify-between gap-2 rounded-md px-3 py-2.5 text-base font-medium transition-colors',
          'hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring',
          'aria-[current=page]:bg-accent/60 aria-[current=page]:text-accent-foreground',
          nested && 'pl-6 text-sm',
        )}
      >
        <span>{label}</span>
        {isExternal && (
          <>
            <ArrowTopRightOnSquareIcon className="h-4 w-4 shrink-0" aria-hidden="true" />
            {opensInNewTab && <span className="sr-only">(opens in new tab)</span>}
          </>
        )}
      </ResolvedLink>
    </div>
  )
}

function MobileDropdown({
  title,
  links,
  pathname,
  index,
  onNavigate,
}: {
  title: string
  links: NavLinkItem[]
  pathname: string
  index: number
  onNavigate: () => void
}) {
  // Open the section if it contains the active route.
  const containsActive = links.some((l) => {
    if (stegaClean(l.link?.linkType) === 'href') return false
    const href = linkResolver(l.link)
    return typeof href === 'string' && href === pathname
  })
  const [open, setOpen] = useState(containsActive)

  return (
    <Collapsible
      open={open}
      onOpenChange={setOpen}
      className="mobile-nav-item"
      style={{'--reveal-i': index} as CSSVars}
    >
      <CollapsibleTrigger
        className={cn(
          'group flex w-full items-center justify-between gap-2 rounded-md px-3 py-2.5 text-base font-medium transition-colors',
          'hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring',
        )}
      >
        <span>{title}</span>
        <ChevronDownIcon
          className="h-4 w-4 shrink-0 transition-transform duration-200 motion-reduce:transition-none group-data-[state=open]:rotate-180"
          aria-hidden="true"
        />
      </CollapsibleTrigger>
      <CollapsibleContent className="overflow-hidden data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down">
        <div className="flex flex-col gap-0.5 py-1">
          {links.map((child, i) => (
            <MobileLeaf
              key={child._key}
              link={child}
              pathname={pathname}
              index={index + i}
              nested
              onNavigate={onNavigate}
            />
          ))}
        </div>
      </CollapsibleContent>
    </Collapsible>
  )
}

/**
 * Hamburger ↔ close morph. Three bars; the outer two rotate to an X and the
 * middle one fades out when `open`. Motion-safe; reduced motion swaps instantly.
 */
function HamburgerIcon({open}: {open: boolean}) {
  return (
    <span className="relative block h-5 w-5" aria-hidden="true">
      <span
        className={cn(
          'absolute left-0 top-[3px] h-0.5 w-5 rounded-full bg-current transition-transform duration-300 motion-reduce:transition-none',
          open && 'translate-y-[7px] rotate-45',
        )}
      />
      <span
        className={cn(
          'absolute left-0 top-[9px] h-0.5 w-5 rounded-full bg-current transition-opacity duration-200 motion-reduce:transition-none',
          open && 'opacity-0',
        )}
      />
      <span
        className={cn(
          'absolute left-0 top-[15px] h-0.5 w-5 rounded-full bg-current transition-transform duration-300 motion-reduce:transition-none',
          open && '-translate-y-[5px] -rotate-45',
        )}
      />
    </span>
  )
}
