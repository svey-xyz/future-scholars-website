'use client'

/**
 * This file is used for onboarding when you don't have content yet and are using the template for the first time.
 * Once you have provided a url for the environment variable NEXT_PUBLIC_SANITY_STUDIO_URL, and have content, you can delete this file.
 */

import Link from 'next/link'
import {useIsPresentationTool} from 'next-sanity/hooks'
import {createDataAttribute} from 'next-sanity'
import {uuid} from '@sanity/uuid'
import {PlusIcon} from '@heroicons/react/24/outline'

import {studioUrl} from '@/sanity/lib/api'
import {Button} from '@/components/ui/button'
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card'

const SanityLogo = () => (
  <svg
    className="mx-auto h-10 w-10"
    aria-hidden="true"
    width="512"
    height="512"
    viewBox="0 0 512 512"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <rect width="512" height="512" fill="#ffffff" rx="30" />
    <path
      d="M161.527 136.723C161.527 179.76 187.738 205.443 240.388 219.095L296 232.283C345.687 243.852 376 272.775 376 319.514C376 341.727 369.162 360.931 357.538 375.971C357.538 329.232 333.607 303.78 276.171 288.74L221.47 276.246C177.709 266.065 143.977 242.464 143.977 191.56C143.977 170.505 150.359 151.994 161.527 136.723Z"
      fill="#F03E2F"
    />
    <path
      opacity="0.5"
      d="M323.35 308.176C347.054 323.679 357.538 345.197 357.538 376.202C337.709 401.654 303.293 416 262.724 416C194.575 416 146.484 381.756 136 322.753H201.641C210.074 350.056 232.41 362.551 262.268 362.551C298.735 362.32 322.895 342.652 323.35 308.176Z"
      fill="#F03E2F"
    />
    <path
      opacity="0.5"
      d="M195.715 200.816C172.923 186.007 161.527 165.183 161.527 136.954C180.672 111.503 213.493 96 253.835 96C323.35 96 363.692 133.252 373.721 185.776H310.359C303.293 165.183 285.971 148.986 254.291 148.986C220.33 148.986 197.311 169.116 195.715 200.816Z"
      fill="#F03E2F"
    />
  </svg>
)

type OnboardingMessageProps = {
  message: {
    title: string
    description: string
  }
  link: {
    title: string
    href: string
  }
  type?: string
  path?: string
}

export function OnboardingShell({message, link, type, path}: OnboardingMessageProps) {
  const isPresentation = useIsPresentationTool()

  return (
    <Card className="max-w-2xl mx-auto text-center">
      <CardHeader className="items-center">
        <SanityLogo />
        <CardTitle className="text-2xl mt-4">{message.title}</CardTitle>
        <CardDescription>{message.description}</CardDescription>
      </CardHeader>
      <CardContent />
      <CardFooter className="justify-center pb-6">
        {!isPresentation ? (
          <Button asChild className="rounded-full">
            <Link href={link.href} target="_blank" rel="noopener noreferrer">
              <PlusIcon className="h-5 w-5" />
              {link.title}
            </Link>
          </Button>
        ) : (
          <Button
            className="rounded-full"
            data-sanity={createDataAttribute({id: uuid(), type, path}).toString()}
          >
            <PlusIcon className="h-5 w-5" />
            {link.title}
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
